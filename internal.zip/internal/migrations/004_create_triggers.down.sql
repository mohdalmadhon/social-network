DROP TRIGGER IF EXISTS increase_post_count;
DROP TRIGGER IF EXISTS decrease_post_count;

DROP TRIGGER IF EXISTS increase_following_count;
DROP TRIGGER IF EXISTS increase_follower_count;
DROP TRIGGER IF EXISTS decrease_following_count;
DROP TRIGGER IF EXISTS decrease_follower_count;

DROP TRIGGER IF EXISTS increase_members_count;
DROP TRIGGER IF EXISTS decrease_members_count;

DROP TRIGGER IF EXISTS increase_comment_count;
DROP TRIGGER IF EXISTS decrease_comment_count;

DROP TRIGGER IF EXISTS increase_reaction_like;
DROP TRIGGER IF EXISTS increase_reaction_dislike;
DROP TRIGGER IF EXISTS decrease_reaction_like;
DROP TRIGGER IF EXISTS decrease_reaction_dislike;

DROP TRIGGER IF EXISTS increase_reaction_comment_like;
DROP TRIGGER IF EXISTS increase_reaction_comment_dislike;
DROP TRIGGER IF EXISTS decrease_reaction_comment_like;
DROP TRIGGER IF EXISTS decrease_reaction_comment_dislike;