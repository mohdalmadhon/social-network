<script setup>
import { ref, watch, onBeforeUnmount } from 'vue'
import { getSuggestedLocations } from '@/api/common/location'
import { getLocationData } from '@/helpers/common/locationHelpers'

const props = defineProps({
  modelValue: {
    type: String,
    default: ''
  },
  open: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits([
  'update:modelValue',
  'close'
])

const search = ref('')
const locations = ref([])
const selectedLocation = ref(null)
const searching = ref(false)

let searchTimeout = null

watch(
  () => props.open,
  (open) => {
    if (!open) {
      clearTimeout(searchTimeout)
      locations.value = []
      selectedLocation.value = null
      searching.value = false
      search.value = ''
    } else if (props.modelValue) {
      search.value = props.modelValue.split(':')[0].trim()
    }
  }
)

function handleLocationSearch() {
  clearTimeout(searchTimeout)

  selectedLocation.value = null

  if (!search.value.trim()) {
    locations.value = []
    return
  }

  searchTimeout = setTimeout(async () => {
    searching.value = true

    try {
      const result = await getSuggestedLocations(search.value.trim())
      locations.value = getLocationData(result)
    } catch (error) {
      console.error(error)
      locations.value = []
    } finally {
      searching.value = false
    }
  }, 500)
}

function selectLocation(location) {
  selectedLocation.value = location

  search.value = `${location.city || location.state}, ${location.country}`

  locations.value = []
}

function confirmLocation() {
  if (!selectedLocation.value) return

  const location = selectedLocation.value

  const value =
    `${location.country}, ` +
    `${location.city || location.state}:` +
    `${location.lat}:` +
    `${location.lon}`

  emit('update:modelValue', value)
  emit('close')
}

function removeLocation() {
  emit('update:modelValue', '')
  emit('close')
}

function closeDialog() {
  emit('close')
}

function handleEscape(event) {
  if (event.key === 'Escape' && props.open) {
    closeDialog()
  }
}

window.addEventListener('keydown', handleEscape)

onBeforeUnmount(() => {
  clearTimeout(searchTimeout)
  window.removeEventListener('keydown', handleEscape)
})
</script>

<template>
  <Teleport to="body">
    <div
      v-if="open"
      class="location-overlay"
      @click.self="closeDialog"
    >
      <div
        class="location-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="location-title"
      >
        <div class="location-header">
          <div>
            <h2 id="location-title">Add location</h2>
            <p>Choose where this post was made.</p>
          </div>

          <button
            type="button"
            class="close-button"
            aria-label="Close"
            @click="closeDialog"
          >
            ×
          </button>
        </div>

        <div class="location-content">
          <label for="location-search">
            Search location
          </label>

          <div class="location-input-wrapper">
            <input
              id="location-search"
              v-model="search"
              type="text"
              placeholder="Search for a city or place..."
              autocomplete="off"
              @input="handleLocationSearch"
            >

            <span
              v-if="searching"
              class="searching"
            >
              Searching...
            </span>
          </div>

          <div
            v-if="locations.length"
            class="location-suggestions"
          >
            <button
              v-for="location in locations"
              :key="location.link || `${location.lat}-${location.lon}`"
              type="button"
              class="location-suggestion"
              @click="selectLocation(location)"
            >
              <span class="location-name">
                {{ location.city || location.state }}
              </span>

              <span class="location-country">
                {{ location.country }}
              </span>
            </button>
          </div>

          <div
            v-if="selectedLocation"
            class="selected-location"
          >
            <div class="selected-icon">
              📍
            </div>

            <div>
              <strong>
                {{ selectedLocation.city || selectedLocation.state }}
              </strong>

              <span>
                {{ selectedLocation.country }}
              </span>
            </div>
          </div>

          <div
            v-if="modelValue && !selectedLocation"
            class="current-location"
          >
            <span>
              Current:
              {{ modelValue.split(':')[0].trim() }}
            </span>

            <button
              type="button"
              @click="removeLocation"
            >
              Remove
            </button>
          </div>
        </div>

        <div class="location-actions">
          <button
            type="button"
            class="cancel-button"
            @click="closeDialog"
          >
            Cancel
          </button>

          <button
            type="button"
            class="remove-button"
            v-if="modelValue"
            @click="removeLocation"
          >
            Remove
          </button>

          <button
            type="button"
            class="add-button"
            :disabled="!selectedLocation"
            @click="confirmLocation"
          >
            Add location
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<style scoped>
.location-overlay {
  position: fixed;
  inset: 0;
  z-index: 9999;

  display: flex;
  align-items: center;
  justify-content: center;

  padding: 20px;

  background: rgb(0 0 0 / 55%);
  backdrop-filter: blur(5px);
}

.location-dialog {
  width: 100%;
  max-width: 480px;

  overflow: hidden;

  border: 2px solid var(--main-color);
  border-radius: 8px;

  background: var(--bg-color);
  color: var(--font-color);

  box-shadow: 7px 7px var(--main-color);
}

.location-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  padding: 20px;

  border-bottom: 2px solid var(--main-color);
}

.location-header h2 {
  margin: 0;

  font-size: 18px;
}

.location-header p {
  margin: 5px 0 0;

  color: var(--font-color-sub);
  font-size: 12px;
}

.close-button {
  display: flex;
  align-items: center;
  justify-content: center;

  width: 32px;
  height: 32px;

  border: 2px solid var(--main-color);
  border-radius: 5px;

  background: var(--bg-color);
  color: var(--font-color);

  font-size: 20px;
  cursor: pointer;
}

.close-button:hover {
  background: var(--main-color);
  color: white;
}

.location-content {
  position: relative;
  padding: 20px;
}

.location-content label {
  display: block;
  margin-bottom: 7px;

  color: var(--font-color-sub);

  font-family: "JetBrains Mono", monospace;
  font-size: 10px;
  font-weight: 700;
  letter-spacing: 1px;
  text-transform: uppercase;
}

.location-input-wrapper {
  position: relative;
}

.location-input-wrapper input {
  width: 100%;
  box-sizing: border-box;

  padding: 13px 14px;

  border: 2px solid var(--main-color);
  border-radius: 5px;

  outline: none;

  background: var(--bg-color);
  color: var(--font-color);

  font-size: 14px;
}

.location-input-wrapper input:focus {
  box-shadow: 3px 3px var(--main-color);
}

.searching {
  position: absolute;
  right: 12px;
  top: 50%;

  transform: translateY(-50%);

  color: var(--font-color-sub);
  font-size: 11px;
}

.location-suggestions {
  position: absolute;
  left: 20px;
  right: 20px;
  top: 76px;

  z-index: 5;

  overflow: hidden;

  border: 2px solid var(--main-color);
  border-radius: 5px;

  background: var(--bg-color);

  box-shadow: 3px 3px var(--main-color);
}

.location-suggestion {
  display: flex;
  flex-direction: column;
  gap: 3px;

  width: 100%;

  padding: 12px 14px;

  border: 0;
  border-bottom: 1px solid var(--main-color);

  background: var(--bg-color);
  color: var(--font-color);

  text-align: left;
  cursor: pointer;
}

.location-suggestion:last-child {
  border-bottom: 0;
}

.location-suggestion:hover {
  background: var(--input-focus);
  color: white;
}

.location-name {
  font-size: 13px;
  font-weight: 700;
}

.location-country {
  font-size: 11px;
  opacity: 0.75;
}

.selected-location {
  display: flex;
  align-items: center;
  gap: 12px;

  margin-top: 15px;
  padding: 12px;

  border: 2px solid var(--main-color);
  border-radius: 6px;

  background: var(--page-background);
}

.selected-icon {
  font-size: 22px;
}

.selected-location div:last-child {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.selected-location strong {
  font-size: 13px;
}

.selected-location span {
  color: var(--font-color-sub);
  font-size: 11px;
}

.current-location {
  display: flex;
  align-items: center;
  justify-content: space-between;

  margin-top: 12px;
  padding: 10px 12px;

  border: 1px solid var(--main-color);
  border-radius: 5px;

  font-size: 12px;
}

.current-location button {
  border: 0;
  background: transparent;
  color: #ff6b8a;
  cursor: pointer;
  font-size: 11px;
  font-weight: 700;
}

.location-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;

  padding: 15px 20px;

  border-top: 2px solid var(--main-color);
}

.location-actions button {
  padding: 10px 15px;

  border: 2px solid var(--main-color);
  border-radius: 5px;

  font-family: "JetBrains Mono", monospace;
  font-size: 10px;
  font-weight: 700;

  cursor: pointer;
}

.cancel-button {
  background: var(--bg-color);
  color: var(--font-color);
}

.remove-button {
  background: transparent;
  color: #ff6b8a;
}

.add-button {
  background: var(--input-focus);
  color: white;
  box-shadow: 3px 3px var(--main-color);
}

.add-button:disabled {
  opacity: 0.4;
  cursor: not-allowed;
  box-shadow: none;
}

.add-button:not(:disabled):hover {
  transform: translate(-1px, -1px);
}
</style>
